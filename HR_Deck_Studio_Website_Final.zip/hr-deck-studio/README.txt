HR DECK STUDIO — FREE STATIC WEBSITE
===================================

FILES
-----
index.html  - complete responsive website

BEFORE PUBLISHING
-----------------
1. Open index.html in a text editor.
2. Replace YOUR_EMAIL@example.com with your business email.
3. Replace REPLACE_WITH_NUMBER with your WhatsApp number including country code, digits only.
   Example: 919876543210
4. Replace the LinkedIn placeholder link with your company LinkedIn URL.
5. Optional: replace the text-only hero card with your own business image later.

HOW TO PUBLISH FREE
-------------------
Option A: GitHub Pages
1. Create a free GitHub account.
2. Create a new public repository, e.g. hr-deck-studio.
3. Upload index.html.
4. Open Settings > Pages.
5. Choose Deploy from branch, select main, root, and Save.
6. GitHub will give you a free *.github.io website address.

Option B: Netlify
1. Create a free Netlify account.
2. Use Add new site / Deploy manually.
3. Drag the hr-deck-studio folder (or the ZIP contents) into the deploy area.
4. Netlify will give you a free *.netlify.app address.

The website is intentionally a single HTML file so it is easy to publish and maintain.
